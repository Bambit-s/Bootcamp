import java.util.ArrayList;
import java.util.Collections;

public class Ejercicio01 {

    private static ArrayList<Integer> createArray() {
        ArrayList<Integer> mass = new ArrayList<>();
        for (int i = 0; i < 11; i++) {
            int random_masmenus = (int) (Math.random() * 2);
            int random_number = (int) (Math.random() * 6);
            int result = (random_masmenus == 0) ? (random_number * -1) : (random_number * 1);
            mass.add(result);
        }
        return mass;
    }

    public static void main(String[] args) {
        ArrayList<Integer> massiv = createArray();
        System.out.println(massiv);
        int biggest_number = Collections.max(massiv);
        System.out.println(biggest_number);

    }
}
