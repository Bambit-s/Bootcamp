public class Ejercicio02 {
    public static void main(String[] args) {
        int first = 3;
        int second = 3;
        if (first > second) {
            System.out.println("Primero mas.");
        }
        if (first < second) {
            System.out.println("Segundo mas.");
        }
        if (first == second) {
            System.out.println("Iguales.");
        }
    }
}
