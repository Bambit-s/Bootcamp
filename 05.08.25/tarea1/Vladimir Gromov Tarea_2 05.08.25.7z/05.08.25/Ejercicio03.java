public class Ejercicio03 {
    public static void main(String[] args) {
        String name = "Vladimir";
        System.out.println("Bienvenido " + name);
    }
}
