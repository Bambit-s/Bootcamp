public class Ejercicio07 {
    public static void main(String[] args) {
        for (int i = 1; i < 101; i+=1){
            if (i%2==0 && i %3 == 0){
                System.err.println(i);
            }
        }
    }
}
