public class Ejercicio01 {
    public static void main(String[] args) {
        int first = 6;
        int second = 3;
        System.out.println(first + second);
        System.out.println(first - second);
        System.out.println(first * second);
        System.out.println(first / second);
        System.out.println(first % second);
    }
}
